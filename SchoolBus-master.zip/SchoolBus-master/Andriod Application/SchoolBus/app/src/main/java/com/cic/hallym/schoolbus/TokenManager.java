package com.cic.hallym.schoolbus;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class TokenManager {
    private static final String TAG = "TokenManager";
    public void renewalToken(String url, String id, String token){

        class renewalData extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            @Override
            protected String doInBackground(String... params) {

                String uri = params[0];
                String id = params[1];
                String token = params[2];

                Log.d(TAG, uri);
                Log.d(TAG, id + ", "+ token);

                BufferedReader bufferedReader = null;

                try {
                    String data  = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8"); // name필드에 있는 값 가지고 오기
                    data +=  "&" + URLEncoder.encode("token", "UTF-8") + "=" + URLEncoder.encode(token, "UTF-8");
                    URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();

                    con.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream()); //데이터 쓰기

                    wr.write( data );
                    wr.flush();

                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String line = null;
                    // Read Server Response
                    while((line = bufferedReader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                }
                catch(Exception e){
                    return null;
                }
            }

        }
        renewalData r = new renewalData();
        r.execute(url, id, token);
    }
}
