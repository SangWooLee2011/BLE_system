package com.cic.hallym.schoolbus;

public interface __Setting__ {
    public static final String SERVER_URL = "http://210.115.227.108/KindergartenBus_Server/Final/";

}
