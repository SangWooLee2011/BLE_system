package com.cic.hallym.schoolbus;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

public class TablePageFragment extends Fragment implements __Setting__{
    private static final String TAG = "TablePageFragment";
    private static final String TAG_RESULTS = "TimeTable";
    private static final String TAG_GETONDATE = "getonDate";
    private static final String TAG_GETONTIME = "getonTime";
    private static final String TAG_GETOFFDATE = "getoffDate";
    private static final String TAG_GETOFFTIME ="getoffTime";

    String myJSON = null;

    ArrayList<HashMap<String, String>> timeList;

    ListView list;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View newView = inflater.inflate(R.layout.fragment_table, container, false);
        list = (ListView) newView.findViewById(R.id.listView_time);
        timeList = new ArrayList<HashMap<String, String>>();

        SharedPreferences sp = getActivity().getSharedPreferences("LOGINDATA", Context.MODE_PRIVATE);
        String idData = sp.getString("LOGINDATA", "");

        getData(SERVER_URL + "Select_UserTimeTable.php",idData);

        return newView;
    }

    // 이부분 수정
    protected void showList(){
        try {
            Log.d(TAG, myJSON);
            JSONObject jsonObj = new JSONObject(myJSON.substring(myJSON.indexOf("{"), myJSON.lastIndexOf("}") + 1));
            JSONArray tempData = jsonObj.getJSONArray(TAG_RESULTS);
            HashMap<String, String> timetable = null;
            int even = tempData.length() % 2;
            int after_isridding;

            for (int i = 0; i < tempData.length(); i += 2) {
                timetable = new HashMap<String, String>();
                for (int j = i; j < i + 2; j++) {
                    // 홀수 일때
                    if(even == 1) {
                        JSONObject c = null;
                        String time = "";
                        int isridding = -1;
                        after_isridding = -1;
                        if(j % 2 == 0 && tempData.length()-1 != j){
                            c = tempData.getJSONObject(j+1);
                            after_isridding = Integer.parseInt(c.getString("isridding"));
                        }

                        // 마지막 행은 index가 넘어감
                        if(tempData.length() != j) {
                            c = tempData.getJSONObject(j);
                            time = c.getString("time");
                            isridding = Integer.parseInt(c.getString("isridding"));
                            String temp[] = time.split("\\s");

                            // 연속으로 탑승 또는 하차가 아닐때
                            if(after_isridding != isridding) {
                                if (isridding == 0) { // 탑승
                                    timetable.put(TAG_GETONDATE, temp[0]);
                                    timetable.put(TAG_GETONTIME, temp[1]);
                                    if(tempData.length() - 1 == j){
                                        timetable.put(TAG_GETOFFDATE, "비었습니다");
                                        timetable.put(TAG_GETOFFTIME, "비었습니다");
                                    }
                                } else if (isridding == 1) { // 하차
                                    timetable.put(TAG_GETOFFDATE, temp[0]);
                                    timetable.put(TAG_GETOFFTIME, temp[1]);
                                    if(tempData.length() - 1 == j){
                                        timetable.put(TAG_GETONDATE, "비었습니다");
                                        timetable.put(TAG_GETONTIME, "비었습니다");
                                    }
                                }
                                // 연속으로 탑승 또는 하차일 때
                            }else if(after_isridding == isridding){
                                if (after_isridding == 0) {
                                    timetable.put(TAG_GETONDATE, temp[0]);
                                    timetable.put(TAG_GETONTIME, temp[1]);
                                    timetable.put(TAG_GETOFFDATE, "비었습니다");
                                    timetable.put(TAG_GETOFFTIME, "비었습니다");
                                }else{
                                    timetable.put(TAG_GETONDATE, "비었습니다");
                                    timetable.put(TAG_GETONTIME, "비었습니다");
                                    timetable.put(TAG_GETOFFDATE, temp[0]);
                                    timetable.put(TAG_GETOFFTIME, temp[1]);
                                }
                                break;
                            }
                        }
                    // 짝수 일때
                    } else{
                        JSONObject c = null;
                        String time = "";
                        int isridding = -1;

                        after_isridding = -1;
                        if(j % 2 == 0){
                            c = tempData.getJSONObject(j+1);
                            after_isridding = Integer.parseInt(c.getString("isridding"));
                        }

                        c = tempData.getJSONObject(j);
                        time = c.getString("time");
                        isridding = Integer.parseInt(c.getString("isridding"));

                        String temp[] = time.split("\\s");
                        // 연속으로 탑승 또는 하차가 아닐때
                        if(after_isridding != isridding) {
                            if (isridding == 0) { // 탑승
                                timetable.put(TAG_GETONDATE, temp[0]);
                                timetable.put(TAG_GETONTIME, temp[1]);
                            } else if (isridding == 1) { // 하차
                                timetable.put(TAG_GETOFFDATE, temp[0]);
                                timetable.put(TAG_GETOFFTIME, temp[1]);
                            }
                            // 연속으로 탑승 또는 하차일 때
                        }else if(after_isridding == isridding){
                            if (after_isridding == 0) {
                                timetable.put(TAG_GETONDATE, temp[0]);
                                timetable.put(TAG_GETONTIME, temp[1]);
                                timetable.put(TAG_GETOFFDATE, "비었습니다");
                                timetable.put(TAG_GETOFFTIME, "비었습니다");
                            }else{
                                timetable.put(TAG_GETONDATE, "비었습니다");
                                timetable.put(TAG_GETONTIME, "비었습니다");
                                timetable.put(TAG_GETOFFDATE, temp[0]);
                                timetable.put(TAG_GETOFFTIME, temp[1]);
                            }
                            break;
                        }
                    }
                }

                timeList.add(timetable);
            }

            ListAdapter adapter = new SimpleAdapter(
                    getActivity(), timeList, R.layout.itme_time,
                    new String[]{TAG_GETONDATE, TAG_GETONTIME, TAG_GETOFFDATE, TAG_GETOFFTIME},
                    new int[]{R.id.textView_geton_date, R.id.textView_geton_time, R.id.textView_getoff_date, R.id.textView_getoff_time}
            );

            list.setAdapter(adapter);

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (StringIndexOutOfBoundsException se){

        }

    }

    public void getData(String url, String id){
        class GetDataJSON extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... params) {
                String uri = params[0];
                String id = params[1];

                Log.e(TAG, uri);
                Log.e(TAG, id);

                BufferedReader bufferedReader = null;

                try {
                    String data  = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8"); // name필드에 있는 값 가지고 오기

                    URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();

                    con.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream()); //데이터 쓰기

                    wr.write( data );
                    wr.flush();

                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;
                    while((json = bufferedReader.readLine())!= null){
                        sb.append(json+"\n");
                    }
                    return sb.toString().trim();

                }catch(Exception e){
                    return null;
                }
            }

            @Override
            protected void onPostExecute(String result){
                myJSON=result;
                showList();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url, id);
    }
}
