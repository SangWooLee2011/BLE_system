package com.cic.hallym.schoolbus;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

//public class NotePageFragment extends Fragment implements View.OnClickListener{
public class NotePageFragment extends Fragment {
    private static final String TAG = "LoginFragment";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,@Nullable ViewGroup container,@Nullable Bundle savedInstanceState){
        View newView = inflater.inflate(R.layout.fragment_note,container,false);
        return newView;
    }



}
