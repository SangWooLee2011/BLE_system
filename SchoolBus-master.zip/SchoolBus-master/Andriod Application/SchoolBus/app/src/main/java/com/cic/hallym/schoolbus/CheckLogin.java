package com.cic.hallym.schoolbus;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class CheckLogin {
    private static final String SERVER_URL = "http://210.115.227.108/KindergartenBus_Server/Final/select_test.php";
    private static final String TAG="CheckLogin";
    private static final String TAG_RESULTS="webnautes";
    private static final String TAG_ID = "id";
    private static final String TAG_PW = "password";

    String myJSON = null;
    JSONArray testData = null;
    ArrayList<HashMap<String, String>> infoList;
    ListView list;

    protected void checkinfo(){
        try {
            Log.d(TAG, myJSON);
            JSONObject jsonObj = new JSONObject(myJSON);
            testData = jsonObj.getJSONArray(TAG_RESULTS);

            for(int i=0;i<testData.length();i++){
                JSONObject c = testData.getJSONObject(i);
                String id = c.getString(TAG_ID);
                String password = c.getString(TAG_PW);



                HashMap<String,String> persons = new HashMap<String,String>();

                persons.put(TAG_ID,id);
                persons.put(TAG_PW,password);

                infoList.add(persons);
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
    public void getData(String url){
        class GetDataJSON extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... params) {

                String uri = params[0];
                Log.d(TAG, uri);
                BufferedReader bufferedReader = null;
                try {
                    URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;
                    while((json = bufferedReader.readLine())!= null){
                        sb.append(json+"\n");
                    }
                    return sb.toString().trim();

                }catch(Exception e){
                    return null;
                }

            }

            @Override
            protected void onPostExecute(String result){
                myJSON=result;
                checkinfo();

            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url);
    }


}
