package com.cic.hallym.schoolbus;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class SignUpActivity extends AppCompatActivity implements __Setting__ {
    private String TAG = "SignUpActivity";
    //layout에 있는 EditText의 변수 선언
    private EditText editTextID;
    private EditText editTextPW1;
    private EditText editTextPW2;
    private EditText editTextNAME;
    private EditText editTextCHILDNAME;
    private EditText editTextEMAIL;
    private EditText editTextPHONE;
    private EditText editTextMAJOR;
    private EditText editTextMINOR;

    private String TAG_RESULTS = "CheckingID";
    private String TAG_checkID = "";
    private int isCheck = 0;
    private String token = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        editTextID = (EditText) findViewById(R.id.editText_id);
        editTextPW1 = (EditText) findViewById(R.id.editText_pw1);
        editTextPW2 = (EditText) findViewById(R.id.editText_pw2);
        editTextNAME = (EditText) findViewById(R.id.editText_name);
        editTextCHILDNAME = (EditText) findViewById(R.id.editText_childname);
        editTextEMAIL = (EditText) findViewById(R.id.editText_email);
        editTextPHONE = (EditText) findViewById(R.id.editText_phone);
        editTextMAJOR = (EditText) findViewById(R.id.editText_major);
        editTextMINOR = (EditText) findViewById(R.id.editText_minor);
    }


    //회원가입버튼 눌렀을때
    public void signUp(View view){
        String TAGID = editTextID.getText().toString(); // 데이터를 텍스트필드로 부터 받아온다.
        String TAGPW1 = editTextPW1.getText().toString();
        String TAGPW2 = editTextPW2.getText().toString();
        String TAGNAME = editTextNAME.getText().toString();
        String TAGCHILDNAME = editTextCHILDNAME.getText().toString();
        String TAGEMAIL = editTextEMAIL.getText().toString();
        String TAGPHONE = editTextPHONE.getText().toString();
        String TAGMAJOR = editTextMAJOR.getText().toString();
        String TAGMINOR = editTextMINOR.getText().toString();

        if(!TAGID.equals("") && !TAGPW1.equals("") && !TAGPW2.equals("") && !TAGNAME.equals("") && !TAGCHILDNAME.equals("") && !TAGEMAIL.equals("") && !TAGPHONE.equals("") && !TAGMAJOR.equals("") && !TAGMINOR.equals("")){
            // id 중복
//            checkDataInServer(TAGID);

            if(TAGPW1.equals(TAGPW2)) {
                insertToDatabase(TAGID, TAGPW1, TAGNAME, TAGCHILDNAME, TAGEMAIL, TAGPHONE, TAGMAJOR, TAGMINOR); //데이터 베이스 관련 함수로 보낸다.
                Toast.makeText(getApplicationContext(), "회원가입이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                Intent intent01 = new Intent(getApplicationContext(), HomeActivity.class);
                intent01.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent01);
            }
            else {
                Toast.makeText(getApplicationContext(), "비밀번호가 다릅니다.", Toast.LENGTH_SHORT).show();
            }
        }
        else{
            Toast.makeText(getApplicationContext(), "입력하지 않은 항목이 있습니다.", Toast.LENGTH_SHORT).show();
        }
    }

    // 취소버튼 눌렀을때
    public void cancel(View view){
        Intent intent02 = new Intent(getApplicationContext(), HomeActivity.class);
        intent02.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent02);
    }

    protected void checkData(String myJSON){
        try {
            Log.d(TAG,myJSON);
            JSONObject jsonObj = new JSONObject(myJSON.substring(myJSON.indexOf("{"), myJSON.lastIndexOf("}") + 1));
            JSONObject c = jsonObj.getJSONArray(TAG_RESULTS).getJSONObject(0);
            isCheck = Integer.parseInt(c.getString(TAG_checkID));
            Log.d(TAG,String.valueOf(isCheck));

            // 중복된 경우
            if (isCheck == 1) {
                Toast.makeText(getApplication(), "아이디가 중복됩니다.", Toast.LENGTH_LONG).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void insertToDatabase(String id, String pw1, String name, String childname, String email, String phone, String major, String minor){

        class InsertData extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(SignUpActivity.this, "Please Wait", null, true, true); //다이어로그 생성
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
            }

            @Override // 데이터베이스로 데이터를 옮겨주는 메소드
            protected String doInBackground(String... params) {

                try{
                    String id = (String)params[0];
                    String pw = (String)params[1];
                    String name = (String)params[2];
                    String childname = (String)params[3];
                    String email = (String)params[4];
                    String phone = (String)params[5];
                    String major = (String)params[6];
                    String minor = (String)params[7];


                    String data  = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8"); // name필드에 있는 값 가지고 오기
                    data += "&" + URLEncoder.encode("pw", "UTF-8") + "=" + URLEncoder.encode(pw, "UTF-8");
                    data += "&" + URLEncoder.encode("name", "UTF-8") + "=" + URLEncoder.encode(name, "UTF-8");
                    data += "&" + URLEncoder.encode("childname", "UTF-8") + "=" + URLEncoder.encode(childname, "UTF-8");
                    data += "&" + URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8");
                    data += "&" + URLEncoder.encode("phonenumber", "UTF-8") + "=" + URLEncoder.encode(phone, "UTF-8");
                    data += "&" + URLEncoder.encode("major", "UTF-8") + "=" + URLEncoder.encode(major, "UTF-8");
                    data += "&" + URLEncoder.encode("minor", "UTF-8") + "=" + URLEncoder.encode(minor, "UTF-8");


                    URL url = new URL(SERVER_URL+"SignUp.php"); // URL에 내가 지정해준 주소로 간다.
                    URLConnection conn = url.openConnection(); //주소를 통해서 열어준다.

                    conn.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream()); //데이터 쓰기

                    wr.write( data );
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                }
                catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }

            }
        }

        InsertData task = new InsertData();
        task.execute(id, pw1, name, childname, email, phone, major, minor); // 데이터를 데이터 베이스에 삽입
    }

    /*
    public void checkDataInServer(String id){
        class GetDataJSON extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            // 백그라운드가 실행되기 전에 사용자와 상호작용할 수 있도록 다이얼로그를 보여준다.
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                // activity가 전환 할때 적용이 됨 fragment전환시 적용 X
//                loading = ProgressDialog.show(getActivity() , "Please Wait", null, true, true); //다이어로그 생성
            }

            @Override
            protected String doInBackground(String... params) {
                String id = params[0];
                Log.d(TAG, id);

                BufferedReader bufferedReader = null;

                try {
                    String data  = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8"); // name필드에 있는 값 가지고 오기
                    URL url = new URL(SERVER_URL+"CheckID.php");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();

                    con.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream()); //데이터 쓰기

                    wr.write( data );
                    wr.flush();

                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;
                    while((json = bufferedReader.readLine())!= null){
                        sb.append(json+"\n");
                    }
                    return sb.toString().trim();

                }catch(Exception e){
                    return null;
                }

            }

            @Override
            protected void onPostExecute(String result){
                checkData(result);
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(id);
    }
    */

}
