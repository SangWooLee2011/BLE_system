package com.cic.hallym.schoolbus;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

public class HomePageFragment extends Fragment implements __Setting__{
    private static final String TAB = "HomePageFragment";
    private static final String TAG_TIME_RESULTS = "latestTime"; // timeTable
    private static final String TAG_SENSOR_RESULTS = "sensor"; // sensor

    private static final String TAG_TIME = "time";
    private static final String TAG_ISRDDING = "isridding";

    private static final String TAG_TEMP = "temp";
    private static final String TAG_HUMI = "humi";
    private static final String TAG_ILLUM = "illum";


    private TextView nowGeton;
    private TextView nowGetoff;
    private TextView getonTime;
    private TextView getOffTime;

    private TextView temperature;
    private TextView humidity;
    private TextView illumination;

    private String geton_time;
    private String getoff_time;

    ArrayList<HashMap<String, String>> timetableList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View newView = inflater.inflate(R.layout.fragment_home, container, false);
        SharedPreferences sp = getActivity().getSharedPreferences("LOGINDATA", Context.MODE_PRIVATE);
        String idData = sp.getString("LOGINDATA", "");

        nowGeton = (TextView) newView.findViewById(R.id.isGeton);
        nowGetoff = (TextView) newView.findViewById(R.id.isGetOff);
        getonTime = (TextView) newView.findViewById(R.id.getonTime);
        getOffTime = (TextView) newView.findViewById(R.id.getoffTime);

        temperature = (TextView) newView.findViewById(R.id.textView_temp);
        humidity = (TextView) newView.findViewById(R.id.textView_humi);
        illumination = (TextView) newView.findViewById(R.id.textView_illum);


        Log.d(TAB, idData);

        getLatestTimeData(SERVER_URL + "Select_LatestTimeTable.php", idData);
        getLatestSensorData(SERVER_URL + "Select_LatestSensor.php");


        return newView;
    }


    protected void showLatestTimeData(String myJSON){
        try {
                Log.d(TAB+"1", String.valueOf(myJSON.length()));
                Log.d(TAB+"1", myJSON);
                JSONObject jsonObj = new JSONObject(myJSON.substring(myJSON.indexOf("{"), myJSON.lastIndexOf("}") + 1));
                JSONArray tempData = jsonObj.getJSONArray(TAG_TIME_RESULTS);

                for (int i = 0; i < tempData.length(); i++) {
                    JSONObject c = tempData.getJSONObject(i);
                    String time = c.getString(TAG_TIME);
                    int isRidding = Integer.parseInt(c.getString(TAG_ISRDDING));

                    Log.d(TAB, time);
                    Log.d(TAB, String.valueOf(isRidding));

                    if (i == 0) {
                        if (isRidding == 0) { // 탑승
                            nowGeton.setTextColor(Color.BLUE);
                            nowGetoff.setTextColor(Color.BLACK);
                            getonTime.setText(time); // 탑승시간 입력
                        } else { // 하차
                            nowGeton.setTextColor(Color.BLACK);
                            nowGetoff.setTextColor(Color.BLUE);
                            getOffTime.setText(time); // 하차시간 입력
                        }
                    } else {
                        if (isRidding == 0) { // 탑승
                            getonTime.setText(time); // 탑승시간 입력
                        } else { // 하차
                            getOffTime.setText(time); // 하차시간 입력
                        }
                    }
                }

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (StringIndexOutOfBoundsException se){
            getonTime.setText("정보가 없습니다."); // 탑승시간 입력
            getOffTime.setText("정보가 없습니다."); // 하차시간 입력
        }


    }

    public void getLatestTimeData(String url, String id){
        class GetDataJSON extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... params) {

                String uri = params[0];
                String id = params[1];

                Log.e(TAB, uri + " " + id);
                BufferedReader bufferedReader = null;
                try {
                    String data  = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8"); // name필드에 있는 값 가지고 오기
                    URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();

                    con.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream()); //데이터 쓰기

                    wr.write( data );
                    wr.flush();

                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;
                    while((json = bufferedReader.readLine())!= null){
                        sb.append(json+"\n");
                    }
                    return sb.toString().trim();

                }catch(Exception e){
                    return null;
                }

            }

            @Override
            protected void onPostExecute(String result){
                Log.d(TAB+'2', result);
                showLatestTimeData(result);
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url, id);
    }


    protected void showLatestSensorData(String myJSON){
        try {
            Log.d(TAB, myJSON);
            JSONObject jsonObj = new JSONObject(myJSON.substring(myJSON.indexOf("{"), myJSON.lastIndexOf("}") + 1));
            JSONObject c = jsonObj.getJSONArray(TAG_SENSOR_RESULTS).getJSONObject(0);

            String temp_data = c.getString(TAG_TEMP);
            String humi_data = c.getString(TAG_HUMI);
            String illum_data = c.getString(TAG_ILLUM);

            temperature.setText(temp_data); // 온도 입력
            humidity.setText(humi_data); // 습도 입력
            illumination.setText(illum_data); // 조도 입력
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (StringIndexOutOfBoundsException se){
            temperature.setText("정보가 없습니다.");
            humidity.setText("정보가 없습니다.");
            illumination.setText("정보가 없습니다.");
        }

    }



    public void getLatestSensorData(String url){
        class GetDataJSON extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... params) {

                String uri = params[0];
                Log.e(TAB, uri);
                BufferedReader bufferedReader = null;

                try {
                    URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;
                    while((json = bufferedReader.readLine())!= null){
                        sb.append(json+"\n");
                    }
                    return sb.toString().trim();

                }catch(Exception e){
                    return null;
                }

            }

            @Override
            protected void onPostExecute(String result){
                showLatestSensorData(result);
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url);
    }



    // Flagement에서 onCreateView를 마치고, Activity에서 onCreate()가 호출되고 나서 호출되는 메소드
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    // Activity의 onStart와 같은 역할
    @Override
    public void onStart() {
        super.onStart();
    }
}
