package com.cic.hallym.schoolbus;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;

public class HomeActivity extends AppCompatActivity implements __Setting__{

    private  BottomNavigationView navigation;
//    private TextView mTextMessage;
    private String TAG = "HomeActivity";

    private  SharedPreferences sp;
    // FrameLayout에 각 메뉴의 Fragment를 바꿔 줌
    private FragmentManager fragmentManager = getSupportFragmentManager();
    // 3개의 메뉴에 들어갈 Fragment들
    private LoginPageFragment loginFragment = new LoginPageFragment();
    private HomePageFragment homeFragment = new HomePageFragment();
    private TablePageFragment tableFragment = new TablePageFragment();
    private NotePageFragment noteFragment = new NotePageFragment();

    private ActionBar actionbar = null;

    private boolean isLogin = false;
    private String idData = null;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            sp = getSharedPreferences("LOGINDATA", Context.MODE_PRIVATE);
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    if(idData.equals("")) {
                        transaction.replace(R.id.main_frame, loginFragment).commitAllowingStateLoss();
                    }
                    else {
                        transaction.replace(R.id.main_frame, homeFragment).commitAllowingStateLoss();
                    }
                    return true;
                case R.id.navigation_dashboard:
                    if(idData.equals("")) {
                        transaction.replace(R.id.main_frame, loginFragment).commitAllowingStateLoss();
                    }
                    else {
                        transaction.replace(R.id.main_frame, tableFragment).commitAllowingStateLoss();
                    }
                    return true;
                case R.id.navigation_notifications:
                    if(idData.equals("")) {
                        transaction.replace(R.id.main_frame, loginFragment).commitAllowingStateLoss();
                    }
                    else {
                        transaction.replace(R.id.main_frame, noteFragment).commitAllowingStateLoss();
                    }
                    return true;
            }
            return false;
        }
    };

    // Login Fragment와 상호작용
    public void setUserData(String id){
        idData = id;
        String title = getString(R.string.app_name) + "\t\t\t"  + idData + "님 환영합니다";
        actionbar.setTitle(title);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        actionbar = getSupportActionBar();

        FirebaseMessaging.getInstance().subscribeToTopic("Alarm");

        setContentView(R.layout.activity_home);
        navigation = (BottomNavigationView) findViewById(R.id.navigation);

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        //액티비티가 중단되었다가 다시 시작

    }

    @Override
    protected void onStart() {
        super.onStart();
        //액티비티가 화면에 나타나기 시작

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        sp = getSharedPreferences("LOGINDATA", Context.MODE_PRIVATE);
        idData = sp.getString("LOGINDATA", "");
        Log.d(TAG, idData);

        if(idData.equals("")) {
            transaction.replace(R.id.main_frame, loginFragment).commitAllowingStateLoss();
            String title = getString(R.string.app_name);
            actionbar.setTitle(title);
        }else {
            transaction.replace(R.id.main_frame, homeFragment).commitAllowingStateLoss();
            String title = getString(R.string.app_name) + "\t\t"  + idData + "님 환영합니다";
            actionbar.setTitle(title);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        //액티비티가 화면에 나타나고 상호작용이 가능해짐

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.actionbar_actions, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_logout :
                // TODO : process the click event for action_search item.
                TokenManager tm = new TokenManager();
                tm.renewalToken(SERVER_URL+"Token_Resigser.php", idData, "");
                idData = ""; // id 제거
                SharedPreferences.Editor editor = sp.edit();
                editor.remove("LOGINDATA"); // 삭제
                editor.remove("TOKENDATA"); // 삭제
                editor.commit(); // 실행한다.



                Toast.makeText(getApplication(), "로그아웃", Toast.LENGTH_LONG).show();
                onStart();
                return true ;

            default :
                return super.onOptionsItemSelected(null);
        }
    }

}
