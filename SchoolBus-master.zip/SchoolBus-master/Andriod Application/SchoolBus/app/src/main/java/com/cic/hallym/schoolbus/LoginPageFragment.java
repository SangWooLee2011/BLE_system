package com.cic.hallym.schoolbus;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class LoginPageFragment extends Fragment implements  __Setting__, View.OnClickListener{
    private static final String TAG = "LoginFragment";
    private static final String TAG_RESULTS = "CheckingLogin";
    private static final String TAG_IsLogin = "isLogin";
    private String idData = "";
    String myJSON = null;
    private int isLogin = 0;

    private Button but_login;
    private Button but_signup;
    private EditText editTextId;
    private EditText editTextPw;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,@Nullable ViewGroup container,@Nullable Bundle savedInstanceState){
        View newView = inflater.inflate(R.layout.fragment_login,container,false);

        FirebaseMessaging.getInstance().subscribeToTopic("Alarm");
        FirebaseInstanceId.getInstance();

        but_login = (Button) newView.findViewById(R.id.button_login);
        but_signup = (Button) newView.findViewById(R.id.button_signup);
        editTextId = (EditText) newView.findViewById(R.id.idText);
        editTextPw = (EditText) newView.findViewById(R.id.pwText);

        return newView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        if(savedInstanceState != null) {
            for(String key : savedInstanceState.keySet()) {
                Log.v(TAG,"savedInstanceState key : " + key);
            }
        }
        super.onActivityCreated(savedInstanceState);

        but_login.setOnClickListener(this);
        but_signup.setOnClickListener(this);
    }

    public void onClick(View v){
        switch (v.getId()){
            // 로그인 ( 성공시, home프레그먼트로 이동 / 실패시, 토스트창으로 로그인 실패 알림 )
            case R.id.button_login:
                String TAGID = editTextId.getText().toString(); // 데이터를 텍스트필드로 부터 받아온다.
                String TAGPW = editTextPw.getText().toString();

                checkDataInServer(SERVER_URL + "Login.php", TAGID, TAGPW);
                break;

             // 회원가입 (인텐트)
            case R.id.button_signup:
                Intent intent02 = new Intent(getActivity(), SignUpActivity.class);
                intent02.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                startActivity(intent02);
                break;

        }
    }


    protected void checkData(){
        try {
            Log.d(TAG,myJSON);

            JSONObject jsonObj = new JSONObject(myJSON.substring(myJSON.indexOf("{"), myJSON.lastIndexOf("}") + 1));
            JSONObject c = jsonObj.getJSONArray(TAG_RESULTS).getJSONObject(0);
            isLogin = Integer.parseInt(c.getString(TAG_IsLogin));
            Log.d(TAG,String.valueOf(isLogin));
            if (isLogin == 1) {
                // 로그인에 성공했다면 id값을 저장
                SharedPreferences sp = getActivity().getSharedPreferences("LOGINDATA", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("LOGINDATA", idData); // idData의 값을 LOGINDATA.xml에 저장
                editor.commit(); // 실행한다.
                ((HomeActivity)getActivity()).setUserData(idData); // HomeActivity에 사용자 id를 전달
                Toast.makeText(getActivity(), "로그인 성공", Toast.LENGTH_LONG).show();

                sp = getActivity().getSharedPreferences("TOKENDATA",Context.MODE_PRIVATE);
                String token = sp.getString("TOKENDATA", "");
                TokenManager tm = new TokenManager();
                tm.renewalToken(SERVER_URL+"Token_Resigser.php", idData, token);

                changeFragment();

            } else {
                Toast.makeText(getActivity(), "아이디와 비밀번호를 다시 확인해주세요", Toast.LENGTH_LONG).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void changeFragment(){
        HomePageFragment homefragment = new HomePageFragment();
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.main_frame, homefragment).commitAllowingStateLoss();

    }

    public void checkDataInServer(String url, String id, String pw){

        class GetDataJSON extends AsyncTask<String, Void, String> {

            ProgressDialog loading;

            // 백그라운드가 실행되기 전에 사용자와 상호작용할 수 있도록 다이얼로그를 보여준다.
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                // activity가 전환 할때 적용이 됨 fragment전환시 적용 X
//                loading = ProgressDialog.show(getActivity() , "Please Wait", null, true, true); //다이어로그 생성
            }

            @Override
            protected String doInBackground(String... params) {

                String uri = params[0];
                String id = params[1];
                String pw = params[2];
                idData = id;
                Log.d(TAG, uri);
                Log.d(TAG, id + ", "+ pw);

                BufferedReader bufferedReader = null;

                try {
                    String data  = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8"); // name필드에 있는 값 가지고 오기
                    data += "&" + URLEncoder.encode("pw", "UTF-8") + "=" + URLEncoder.encode(pw, "UTF-8");

                    URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();

                    con.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream()); //데이터 쓰기

                    wr.write( data );
                    wr.flush();

                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;
                    while((json = bufferedReader.readLine())!= null){
                        sb.append(json+"\n");
                    }
                    return sb.toString().trim();

                }catch(Exception e){
                    return null;
                }
            }

            @Override
            protected void onPostExecute(String result){
                myJSON=result;
                checkData();
            }

        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url, id, pw);
    }



}
