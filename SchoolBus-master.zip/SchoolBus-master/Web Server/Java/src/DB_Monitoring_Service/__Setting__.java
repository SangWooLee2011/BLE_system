package DB_Monitoring_Service;

/**
 * @author Junhyeong
 */

public class __Setting__ {
	private String DBName = "kindergartenbus"; //db�̸�
	private String strUser = "cic"; // ���� id
	private String strPassword = "20180903in"; // ���� �н�����
	
	
	public String getDBName() {
		return DBName;
	}
	public String getStrUser() {
		return strUser;
	}
	public String getStrPassword() {
		return strPassword;
	}

}
