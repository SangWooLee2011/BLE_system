package DB_Monitoring_Service;

public class NewMember {
	private int membership;

	public NewMember() {
		membership = 0; 
	}
	
	public int getMembership() {
		return membership;
	}

	public void setMembership(int membership) {
		this.membership = membership;
	}
	
	
}
