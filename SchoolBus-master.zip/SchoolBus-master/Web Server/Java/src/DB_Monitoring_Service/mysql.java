package DB_Monitoring_Service;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import DB_Monitoring_Service.Custom_Data_Type.DeviceInfo;
import DB_Monitoring_Service.Custom_Data_Type.DeviceVariable;

public class mysql {
	private String DBName = ""; //db�̸�
	private String url = "jdbc:mysql://210.115.227.108:3306/";// mysql ����
	private String strUser = ""; // ���� id
	private String strPassword = ""; // ���� �н�����
	private String strMySQLDriver = "com.mysql.cj.jdbc.Driver"; // ����̹� �̸�
	private Connection con = null;	//db ����
	private Statement stmt = null;	//db ����, ��µ ���
	private ArrayList list = null;
	
	public mysql() {
        try
        {
        	Class.forName(strMySQLDriver);	//db����̹�����

        } catch (Exception e) {        //try
            System.out.println(e.getMessage());
        }    
	}
	
	private void getUrl(String DBName) {
		url += DBName+"?characterEncoding=UTF-8&serverTimezone=UTC";
	}
	
	private void connect() {
		  try {
    		__Setting__ ss = new __Setting__();
    		
    		DBName = ss.getDBName();
    		strUser = ss.getStrUser();
    		strPassword = ss.getStrPassword();
    		getUrl(DBName);
			con  = (Connection) DriverManager.getConnection(url,strUser,strPassword);
//	        System.out.println("Mysql DB Connection.");
	        stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // ����
		
	}
	
	private void disconnect() {
		if(stmt != null)
		{
			try {
				stmt.close();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		if(con != null)
		{
			try {
				con.close();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}
	
	///////////////////////////////////////////////////////////////////////////
	
	//  �������ð�, ���� id, ����������
	public void input_timetable(String id, String time, int isridding) {
		connect();
		 try {
	         String sql = "insert into timetable_tb values('" + id + "','" +  time + "','" + String.valueOf(isridding) +  "')";	
	         // �������� ���� �� ������ ����
	         int rss  = stmt.executeUpdate(sql);  //executeUpdate�� int ���̴�.

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			disconnect();
		}
	}
	
	public ArrayList<DeviceVariable> select_device_variable_info_tb() {
		connect();
		 try {
			String sql = "select * from device_variable_info_tb";
			ResultSet rs = stmt.executeQuery(sql);
			DeviceVariable dv = null;
			list = new ArrayList<DeviceVariable>();
			while(rs.next()) {
				dv = new DeviceVariable();
				dv.setMacaddress(rs.getString("macaddress"));
				dv.setRssi(rs.getDouble("rssi"));
				dv.setTxpower(rs.getDouble("txpower"));
				dv.setAccuracy(rs.getDouble("accuracy"));
				dv.setTime(rs.getString("time"));
				
				list.add(dv);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return list;
	}
	
	public ArrayList<DeviceInfo> select_device_info() {
		connect();
		 try {
//			String sql = "SELECT DISTINCT macaddress FROM device_variable_info_tb";
			String sql = "SELECT di.macAddress AS macaddress, ul.id AS id FROM device_unique_info_tb AS di JOIN userslist_tb AS ul ON di.major = ul.major AND di.minor = ul.minor";
			ResultSet rs = stmt.executeQuery(sql);
			DeviceInfo di = null;
			list = new ArrayList<String>();
			while(rs.next()) {
				di = new DeviceInfo();
				di.setMacAddress((rs.getString("macAddress")));
				di.setUserID((rs.getString("id")));
				
				list.add(di);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return list;
	}
	
	
	public ArrayList<DeviceVariable> select_recent(int maximum, String macAddress) {
		connect();
		 try {
			String sql = "Select accuracy, time from device_variable_info_tb where macaddress='"+ macAddress + "' ORDER BY time DESC Limit "+ String.valueOf(maximum);
			ResultSet rs = stmt.executeQuery(sql);
			DeviceVariable dv = null;
			list = new ArrayList<DeviceVariable>();
			while(rs.next()) {			
				dv = new DeviceVariable();
				dv.setAccuracy(rs.getDouble("accuracy"));
				dv.setTime(rs.getString("time"));
				
				list.add(dv);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return list;
	}
	///////
	public ArrayList<DeviceVariable> Test_interference(){
		connect();
		 try {
			String sql = "Select * from device_variable_info_tb";
			ResultSet rs = stmt.executeQuery(sql);
			DeviceVariable dv = null;
			list = new ArrayList<DeviceVariable>();
			while(rs.next()) {			
				dv = new DeviceVariable();
				dv.setMacaddress(rs.getString("macaddress"));
				dv.setRssi(rs.getDouble("rssi"));
				dv.setTxpower(rs.getDouble("txpower"));
				dv.setAccuracy(rs.getDouble("accuracy"));
				dv.setTime(rs.getString("time"));
				
				list.add(dv);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return list;
	}


}
