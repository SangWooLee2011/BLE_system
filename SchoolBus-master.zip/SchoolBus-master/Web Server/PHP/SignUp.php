<?php

include_once '__Setting__.php';
$host = DB_HOST;
$username = DB_USER; # MySQL 계정 아이디
$password = DB_PASSWORD; # MySQL 계정 패스워드
$dbname = DB_NAME;  # DATABASE 이름

$con=mysqli_connect($host,$username,$password,$dbname);

mysqli_set_charset($con,"utf8");

if (mysqli_connect_errno($con))
{
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$id = $_POST['id'];
$pw = $_POST['pw'];
$name = $_POST['name'];
$childname = $_POST['childname'];
$email = $_POST['email'];
$phonenumber = $_POST['phonenumber'];
$major = $_POST['major'];
$minor = $_POST['minor'];

// Test용
$sql = "INSERT INTO userslist_tb(id,password,name,childname,email,phonenumber,major,minor) Values ('$id','$pw','$name','$childname','$email','$phonenumber','$major','$minor') ON DUPLICATE KEY UPDATE Token = '$id'; ";

// 실전용
// $sql = "INSERT INTO userslist_tb (id,password,name,childname,email,phonenumber,major,minor,token) values ('$id','$pw','$name','$childname','$email','$phonenumber','$major','$minor','$token')";

$result = mysqli_query($con,$sql);

  if($result){
    echo 'success';
  }
  else{
    echo 'failure';
  }

mysqli_close($con);
?>
