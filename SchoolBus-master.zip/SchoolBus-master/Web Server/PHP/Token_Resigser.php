<?php
	if(isset($_POST["token"])){
		$id = $_POST["id"];
		$token = $_POST["token"];
		//데이터베이스에 접속해서 토큰을 저장
		include_once '__Setting__.php';
		$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
		$query = "UPDATE userslist_tb SET token = '$token' WHERE id = '$id'";

		mysqli_query($conn, $query);

		mysqli_close($conn);
	}
?>
