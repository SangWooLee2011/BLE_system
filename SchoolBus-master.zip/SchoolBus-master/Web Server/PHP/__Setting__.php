<?php

// $_ID = 'cic';
// $_Password ='20180903in';
// $_DBName = 'kindergartenbus';

define("DB_HOST", "localhost");
define("DB_USER", "cic");
define("DB_PASSWORD", "20180903in");
define("DB_NAME", "kindergartenbus");

define("GOOGLE_API_KEY", "AAAAjCDnNcQ:APA91bGfGpUfw7kGRyfjXeA0BLgPM_jcBpY9lXxf6gPB3jNf-VOSHHX7axHz1shEDhhC1HWvBO23M1L7ddq5RSSTZEqK88lYaZFE9L17JAE73skFlRSBzX51eG5h6GrWHCDQ2klf5QY0");



 ?>
