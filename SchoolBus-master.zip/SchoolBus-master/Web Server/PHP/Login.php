Check Login
<?php
ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL);

include_once '__Setting__.php';
$host = DB_HOST;
$username = DB_USER; # MySQL 계정 아이디
$password = DB_PASSWORD; # MySQL 계정 패스워드
$dbname = DB_NAME;  # DATABASE 이름

try {

  $id = $_POST['id'];
  $pw = $_POST['pw'];

  $con = new PDO("mysql:host={$host};dbname={$dbname};charset=utf8",$username, $password);

} catch(PDOException $e) {

    die("Failed to connect to the database: " . $e->getMessage());
}


    $sql = "SELECT EXISTS (select * from userslist_tb where id='$id' AND password='$pw') as isLogin";

    $stmt = $con->prepare($sql);
    // 1이면 로그인 성공 0이면 실패
    $stmt->execute();

    // 로그인 성공
    $data = array();

    while($row=$stmt->fetch(PDO::FETCH_ASSOC))
    {
        extract($row);

        array_push($data,
            array('isLogin'=>$isLogin
        ));
    }

    header('Content-Type: application/json; charset=utf8');
    $json = json_encode(array("CheckingLogin"=>$data), JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE);
    echo $json;

?>
